import RPi.GPIO as GPIO
import time


def led(pin, t):
    
    while(True):
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(pin, GPIO.OUT)

        GPIO.output(pin, True)
        time.sleep(t)
        GPIO.output(pin, False)
        time.sleep(t)
        print("hangul")
        GPIO.cleanup(pin)
        
    
led(5, 3)