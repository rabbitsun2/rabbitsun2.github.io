<?php
    define('NAVER_CLIENT_ID', 'LVUkFeLgps4YKfKxexXh');
    define('NAVER_CLIENT_SECRET', '7Qj1p8Qwdv');
    define('NAVER_CALLBACK_URL', 'http://localhost/naver_login_callback.php');
    $naverUrl = "https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=".NAVER_CLIENT_ID."&redirect_uri=".urlencode(NAVER_CALLBACK_URL);
?>
 
<a href="<?php echo $naverUrl;?>">네이버로그인</a>
